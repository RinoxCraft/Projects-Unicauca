#include "PantallaOled.h"

U8G2_SH1106_128X32_VISIONOX_F_HW_I2C u8g2(U8G2_R0, /* reset=*/ U8X8_PIN_NONE);

void setupOled() {
    u8g2.begin();
}

void updateOled(String message) {
    u8g2.clearBuffer();
    u8g2.setFont(u8g2_font_ncenB08_tr);
    u8g2.setCursor(0, 10);
    u8g2.print(message);
    u8g2.sendBuffer();
}

void displayErrorOnOLED(const char* errorMessage) {
    updateOled(errorMessage);
}

void updateOledWithSensorValues(float temperature, float humidity, int lightIntensity) {
    u8g2.clearBuffer();
    u8g2.setFont(u8g2_font_ncenB08_tr);
    u8g2.setCursor(0, 10);
    u8g2.print("Temperatura: ");
    u8g2.print(temperature);
    u8g2.print(" C\n");

    u8g2.setCursor(0, 20);
    u8g2.print("Humedad: ");
    u8g2.print(humidity);
    u8g2.print(" %\n");

    u8g2.setCursor(0, 30);
    u8g2.print("Luz: ");
    u8g2.print(lightIntensity);
    u8g2.print(" %\n");

    u8g2.sendBuffer();
}
