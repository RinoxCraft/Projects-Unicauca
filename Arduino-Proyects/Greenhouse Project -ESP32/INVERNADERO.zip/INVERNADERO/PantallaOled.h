#ifndef PANTALLA_OLED_H
#define PANTALLA_OLED_H

#include <U8g2lib.h>
#include <Arduino.h>

void setupOled();
void updateOled(String message);
void displayErrorOnOLED(const char* errorMessage);
void updateOledWithSensorValues(float temperature, float humidity, int lightIntensity);

#endif
