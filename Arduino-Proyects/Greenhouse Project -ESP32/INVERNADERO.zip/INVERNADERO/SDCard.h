#ifndef SDCARD_H
#define SDCARD_H

#include <Arduino.h>
#include <SD.h>

void setupSDCard();

#endif
