#include "Sensores.h"
#include <DHT.h>

Sensores::Sensores(uint8_t pinDHT22, uint8_t pinFotoCelda)
  : pinDHT22(pinDHT22), pinFotoCelda(pinFotoCelda), dht(pinDHT22, DHT22) {}

void Sensores::begin() {
  dht.begin();
  // Aquí podrías agregar código adicional para inicializar otros sensores si es necesario
}

void Sensores::turnOffSensors() {
  // Apagar los sensores
}

void Sensores::turnOnSensors() {
  // Código para encender los sensores
  dht.begin();
}

float Sensores::readTemperature() {
  return dht.readTemperature();
}

float Sensores::readHumidity() {
  return dht.readHumidity();
}

int Sensores::readPhotoCell() {
  int valorFotocelda = analogRead(pinFotoCelda);
  return map(valorFotocelda, 0, 1023, 0, 100);
}
