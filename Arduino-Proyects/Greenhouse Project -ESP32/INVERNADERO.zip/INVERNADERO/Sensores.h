#ifndef SENSORES_H
#define SENSORES_H

#include <DHT.h>

class Sensores {
public:
  Sensores(uint8_t pinDHT22, uint8_t pinFotoCelda);

  void begin();
  void turnOffSensors();
  void turnOnSensors();
  float readTemperature();
  float readHumidity();
  int readPhotoCell();

private:
  uint8_t pinDHT22;
  uint8_t pinFotoCelda;
  DHT dht;
};

#endif
