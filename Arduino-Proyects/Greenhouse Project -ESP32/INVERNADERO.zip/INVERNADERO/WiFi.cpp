#include "WiFi.h"
#include <WiFi.h>

const char* ssid = "Readme";//"TP-LINK_DE16";
const char* password = "13052023";//"67743667";

void setupWiFi() {
  WiFi.mode(WIFI_STA);
  Serial.print("Conectando a WiFi ..");
  while (WiFi.status() != WL_CONNECTED) {
    WiFi.begin(ssid, password);
    Serial.print('.');
    delay(5000); // Reintento cada 5 segundos
  }
  Serial.println(WiFi.localIP());
}

bool checkWiFiConnection() {
  // Verificar si el dispositivo está conectado a WiFi
  if (WiFi.status() == WL_CONNECTED) {
    // El dispositivo está conectado a WiFi
    return true;
  } else {
    // El dispositivo no está conectado a WiFi
    return false;
  }
}
